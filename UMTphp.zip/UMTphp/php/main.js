let id = $("input[name*='student_id']")
id.attr("readonly","readonly");


$(".btnedit").click( e => {	
	let textvalues = displayData(e);
	console.log(textvalues);
    let studentName = $("input[name*='student_name']");
    let degreeName = $("input[name*='degree_name']");
    let graduationYear = $("input[name*='graduation_year']");

    //id.val(3);
    id.val(textvalues[0]);
    studentName.val(textvalues[1]);
    degreeName.val(textvalues[2]);
    graduationYear.val(textvalues[3]);

});

function displayData(e) {
        let id = 0;
        const td = $("#tbody tr td");
        let textvalues = [];

        for (const value of td){
            
            if(value.dataset.id == e.target.dataset.id){
            	textvalues[id++]=value.textContent;
            }
        }
        return textvalues;
    }